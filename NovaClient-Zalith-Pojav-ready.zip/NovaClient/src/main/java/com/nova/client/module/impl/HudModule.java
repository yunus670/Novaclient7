package com.nova.client.module.impl;

import com.nova.client.gui.Draw2D;
import com.nova.client.gui.Theme;
import com.nova.client.gui.UiFont;
import com.nova.client.module.Category;
import com.nova.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

import java.util.Locale;

/** Watermark: a pulsing N, the glowing client name and a translucent coordinates / FPS strip. */
public final class HudModule extends Module {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private double lastX, lastZ;
    private boolean hasLast;
    private double bps;

    public HudModule() {
        super("HUD", "Watermark with name, coordinates and FPS.", Category.RENDER);
        setToggled(true);
    }

    @Override
    public boolean hasKeybind() { return false; }

    @Override
    public void onTick() {
        if (mc.player == null) { hasLast = false; return; }
        double x = mc.player.getX(), z = mc.player.getZ();
        if (hasLast) {
            double instant = Math.hypot(x - lastX, z - lastZ) * 20.0;
            bps += (instant - bps) * 0.25;
        }
        lastX = x;
        lastZ = z;
        hasLast = true;
    }

    @Override
    public void onRender2D(DrawContext ctx) {
        if (mc.player == null || mc.options == null || mc.options.hudHidden) return;

        double t = System.currentTimeMillis() * 0.004;
        float glow = (float) ((Math.sin(t) + 1.0) / 2.0);
        float blink = (float) ((Math.sin(t * 1.3 + 1.2) + 1.0) / 2.0);

        int x = 10, y = 10, h = 16;

        // N logo, fades in and out
        Draw2D.roundedRect(ctx, x, y, x + h, y + h, 4.0F, Theme.argb(40 + (int) (blink * 100)));
        UiFont.drawCentered(ctx, "N", x + h / 2, y + 4, ((int) (140 + 115 * blink) << 24) | 0xFFFFFF);

        String name = "NovaClient 1.21.4";
        String info = infoLine();
        int px = x + h + 4;
        int nameW = UiFont.width(name) + 14;
        int infoW = UiFont.width(info) + 14;

        // coordinates / FPS strip: clearly see-through; name part: only very slightly see-through
        Draw2D.roundedRect(ctx, px, y, px + nameW + infoW, y + h, 4.0F, 0x99101018);
        Draw2D.roundedRect(ctx, px, y, px + nameW, y + h, 4.0F, 0xD2101018);

        // glowing name: soft halo behind, pulsing color on top
        int pulse = Theme.blend(glow) & 0xFFFFFF;
        int halo = ((int) (30 + 50 * glow) << 24) | pulse;
        int tx = px + 7, ty = y + 4;
        UiFont.draw(ctx, name, tx - 1, ty, halo);
        UiFont.draw(ctx, name, tx + 1, ty, halo);
        UiFont.draw(ctx, name, tx, ty - 1, halo);
        UiFont.draw(ctx, name, tx, ty + 1, halo);
        UiFont.draw(ctx, name, tx, ty, 0xFF000000 | pulse);

        UiFont.draw(ctx, info, px + nameW + 7, ty, 0xFFE6E6EE);
    }

    private String infoLine() {
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (entry != null) ping = entry.getLatency();
        }
        return String.format(Locale.ROOT, "%d %d %d | %d FPS | %d MS | %.1f BPS",
                (int) Math.floor(mc.player.getX()), (int) Math.floor(mc.player.getY()),
                (int) Math.floor(mc.player.getZ()), mc.getCurrentFps(), ping, bps);
    }
}
