package com.nova.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Smooth (TrueType) text instead of Minecraft's pixel font. */
public final class UiFont {
    private static final Style STYLE = Style.EMPTY.withFont(Identifier.of("novaclient", "ui"));

    private UiFont() { }

    public static Text of(String s) { return Text.literal(s).setStyle(STYLE); }

    public static int width(String s) { return MinecraftClient.getInstance().textRenderer.getWidth(of(s)); }

    public static void draw(DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawText(MinecraftClient.getInstance().textRenderer, of(s), x, y, color, false);
    }

    public static void drawCentered(DrawContext ctx, String s, int centerX, int y, int color) {
        draw(ctx, s, centerX - width(s) / 2, y, color);
    }

    public static void drawRight(DrawContext ctx, String s, int rightX, int y, int color) {
        draw(ctx, s, rightX - width(s), y, color);
    }

    /** Cuts the text so it fits maxWidth, adding ".." when something was removed. */
    public static String trim(String s, int maxWidth) {
        if (width(s) <= maxWidth) return s;
        while (!s.isEmpty() && width(s + "..") > maxWidth) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
}
