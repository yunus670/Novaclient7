package com.nova.client.module.impl;

import com.nova.client.module.Category;
import com.nova.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.wyrmdrop.aura.WyrmDropAura;

/**
 * NovaClient adapter for the uploaded WyrmDropAura prototype.
 * TargetESP and TargetHUD use getTarget() to render the selected player.
 */
public final class AuraModule extends Module {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public AuraModule() {
        super("Aura", "WyrmDropAura integration prototype.", Category.COMBAT);
    }

    public PlayerEntity getTarget() {
        return WyrmDropAura.getTarget() instanceof PlayerEntity player ? player : null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            WyrmDropAura.clearTarget();
            return;
        }
        // Aura updates are synchronized with movement packet sending by ClientPlayerEntityMixin.
    }

    @Override
    public void onDisable() {
        WyrmDropAura.clearTarget();
    }
}
