package com.nova.client.module.impl;

import com.nova.client.gui.Draw2D;
import com.nova.client.gui.Theme;
import com.nova.client.gui.UiFont;
import com.nova.client.module.Category;
import com.nova.client.module.Module;
import com.nova.client.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** HUD window listing every module that has a key. Enabled ones glow in the theme color. */
public final class KeyBindsModule extends Module {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public KeyBindsModule() {
        super("KeyBinds", "Lists the modules that have a key.", Category.RENDER);
        setToggled(true);
    }

    @Override
    public boolean hasKeybind() { return false; }

    @Override
    public void onRender2D(DrawContext ctx) {
        if (mc.player == null || mc.options == null || mc.options.hudHidden) return;

        List<Module> bound = new ArrayList<>();
        for (Module m : ModuleManager.getModules()) {
            if (m.hasKeybind() && m.getKey() != 0) bound.add(m);
        }
        if (bound.isEmpty()) return;

        int rowHeight = 14;
        int w = UiFont.width("KeyBinds") + 46;
        for (Module m : bound) {
            w = Math.max(w, UiFont.width(m.getName()) + UiFont.width(m.getKeybind().getDisplayName()) + 40);
        }
        w = Math.max(w, 100);
        int h = 18 + bound.size() * rowHeight + 5;
        int x = 10, y = 34;

        Draw2D.roundedRect(ctx, x, y, x + w, y + h, 4.0F, 0xC8121218);
        // header strip in the theme color with a small keyboard icon
        Draw2D.roundedRect(ctx, x, y, x + w, y + 16, 4.0F, Theme.argb(0x80));
        UiFont.draw(ctx, "KeyBinds", x + 8, y + 3, 0xFFFFFFFF);
        Draw2D.roundedRect(ctx, x + w - 20, y + 4, x + w - 6, y + 12, 2.0F, 0x90FFFFFF);
        for (int i = 0; i < 4; i++) ctx.fill(x + w - 18 + i * 3, y + 6, x + w - 17 + i * 3, y + 7, 0xFF121218);
        for (int i = 0; i < 3; i++) ctx.fill(x + w - 17 + i * 4, y + 9, x + w - 15 + i * 4, y + 10, 0xFF121218);

        int ry = y + 19;
        for (Module m : bound) {
            boolean on = m.isToggled();
            String key = m.getKeybind().getDisplayName();
            UiFont.draw(ctx, m.getName(), x + 8, ry, on ? Theme.argb(0xFF) : 0xFFB4B4C0);
            int boxW = Math.max(12, UiFont.width(key) + 8);
            Draw2D.roundedRect(ctx, x + w - 6 - boxW, ry - 1, x + w - 6, ry + 11, 3.0F, on ? Theme.argb(0x70) : 0x40FFFFFF);
            UiFont.drawCentered(ctx, key, x + w - 6 - boxW / 2, ry, 0xFFFFFFFF);
            ry += rowHeight;
        }
    }

    private static void rrect(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        Draw2D.roundedRect(ctx, x1, y1, x2, y2, 4.0F, color);
    }
}
