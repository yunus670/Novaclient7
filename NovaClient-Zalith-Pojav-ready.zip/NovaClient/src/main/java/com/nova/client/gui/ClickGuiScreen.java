package com.nova.client.gui;

import com.nova.client.ConfigManager;
import com.nova.client.NovaClient;
import com.nova.client.module.BindSetting;
import com.nova.client.module.BooleanSetting;
import com.nova.client.module.Category;
import com.nova.client.module.ModeSetting;
import com.nova.client.module.Module;
import com.nova.client.module.ModuleManager;
import com.nova.client.module.NumberSetting;
import com.nova.client.module.impl.ClickGuiModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Five category panels with their own scrolling, smooth text, module rows that turn the theme
 * color when enabled, expandable settings, search bar and the theme color dots.
 */
public final class ClickGuiScreen extends Screen {
    private static final int HEADER = 20;
    private static final int ROW = 15;
    private static final int SETTING_ROW = 14;
    private static final int SLIDER_ROW = 21;

    private static final int[] DOTS = {
            0x9A8CFF, 0x5FA8FF, 0x4FE8D0, 0x62F07A, 0xC4F25A, 0xFFC48A, 0xFF7F7F,
            0xFF6FD0, 0xE070FF, 0xB07CFF, 0x78BEFF, 0xFFFFFF, 0xBBBBBB
    };

    private enum Kind { MODULE, NUMBER, MODE, BOOL, BIND, DOT, SEARCH }

    private record Hit(int x1, int y1, int x2, int y2, Kind kind, Module module, Object setting, int value) {
        boolean contains(double x, double y) { return x >= x1 && x < x2 && y >= y1 && y < y2; }
    }

    private record PanelRect(Category cat, int x1, int y1, int x2, int y2) {
        boolean contains(double x, double y) { return x >= x1 && x < x2 && y >= y1 && y < y2; }
    }

    private final List<Hit> hits = new ArrayList<>();
    private final List<PanelRect> panels = new ArrayList<>();
    private final Map<Category, Integer> scrolls = new EnumMap<>(Category.class);
    private final Set<Module> expanded = new HashSet<>();

    private String search = "";
    private boolean searchFocused;
    private BindSetting listeningBind;

    private Hit slider;            // slider being dragged
    private Hit pressed;           // button pressed, activated on release (so finger scrolling never toggles things)
    private int pressedButton;
    private double pressX, pressY;
    private boolean moved;
    private Category dragPanel;    // panel scrolled by dragging

    public ClickGuiScreen() {
        super(Text.literal("ClickGUI"));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        ClickGuiModule gui = ModuleManager.get(ClickGuiModule.class);
        if (gui != null) gui.forceToggled(false);
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        hits.clear();
        panels.clear();
        ctx.fill(0, 0, width, height, 0x45000000);

        Category[] cats = Category.values();
        int gap = 6;
        int minPw = 96;
        int perRow = Math.max(1, Math.min(cats.length, (width - 16 + gap) / (minPw + gap)));
        int pw = Math.min(122, (width - 16 - gap * (perRow - 1)) / perRow);
        int rows = (cats.length + perRow - 1) / perRow;
        int startX = (width - (perRow * pw + (perRow - 1) * gap)) / 2;

        int availableHeight = height - 100; // room for the search bar and the color dots
        int ph = Math.max(90, Math.min(270, (availableHeight - 14 - gap * (rows - 1)) / rows));

        for (int i = 0; i < cats.length; i++) {
            int col = i % perRow;
            int row = i / perRow;
            drawPanel(ctx, cats[i], startX + col * (pw + gap), 14 + row * (ph + gap), pw, ph, mouseX, mouseY);
        }
        drawBottom(ctx);
    }

    private void drawPanel(DrawContext ctx, Category cat, int x, int y, int pw, int ph, int mouseX, int mouseY) {
        List<Module> mods = visibleModules(cat);
        int contentHeight = 0;
        for (Module m : mods) contentHeight += moduleHeight(m);

        int bodyTop = y + HEADER;
        int bodyBottom = y + ph - 3;
        int bodyHeight = bodyBottom - bodyTop;
        int maxScroll = Math.max(0, contentHeight - bodyHeight + 4);
        int scroll = Math.max(0, Math.min(maxScroll, scrolls.getOrDefault(cat, 0)));
        scrolls.put(cat, scroll);

        rrect(ctx, x - 1, y - 1, x + pw + 1, y + ph + 1, Theme.argb(0x55));
        rrect(ctx, x, y, x + pw, y + ph, 0xE0121218);

        Draw2D.roundedRect(ctx, x + 8, y + 8, x + 14, y + 14, 1.5F, Theme.argb(0xFF));
        UiFont.drawCentered(ctx, cat.getDisplayName(), x + pw / 2, y + 6, 0xFFFFFFFF);
        ctx.fill(x + 6, y + HEADER - 2, x + pw - 6, y + HEADER - 1, 0x28FFFFFF);

        ctx.enableScissor(x, bodyTop, x + pw, bodyBottom);
        int cy = bodyTop + 1 - scroll;
        int rowWidth = pw - 8 - (maxScroll > 0 ? 3 : 0);
        for (Module m : mods) cy = drawModule(ctx, m, x + 4, cy, rowWidth, mouseX, mouseY, bodyTop, bodyBottom);
        ctx.disableScissor();

        if (maxScroll > 0) {
            int thumbHeight = Math.max(10, bodyHeight * bodyHeight / (contentHeight + 4));
            int thumbY = bodyTop + (bodyHeight - thumbHeight) * scroll / maxScroll;
            Draw2D.roundedRect(ctx, x + pw - 4, thumbY, x + pw - 2, thumbY + thumbHeight, 1.0F, Theme.argb(0xB0));
        }
        panels.add(new PanelRect(cat, x, y, x + pw, y + ph));
    }

    private int drawModule(DrawContext ctx, Module m, int x, int y, int w, int mouseX, int mouseY, int top, int bottom) {
        boolean hover = mouseX >= x && mouseX < x + w && mouseY >= Math.max(y, top)
                && mouseY < Math.min(y + ROW, bottom);
        if (m.isToggled()) rrect(ctx, x, y, x + w, y + ROW - 1, Theme.argb(0x30));
        else if (hover) rrect(ctx, x, y, x + w, y + ROW - 1, 0x16FFFFFF);

        String label = m.getName();
        try {
            if (m instanceof ClickGuiModule && NovaClient.openGuiKey != null) {
                label += " [" + NovaClient.openGuiKey.getBoundKeyLocalizedText().getString().toUpperCase(Locale.ROOT) + "]";
            } else if (m.getKey() != 0) {
                label += " [" + m.getKeybind().getDisplayName().toUpperCase(Locale.ROOT) + "]";
            }
        } catch (Throwable ignored) { }

        boolean hasSettings = !m.getSettings().isEmpty();
        int textColor = m.isToggled() ? Theme.argb(0xFF) : 0xFFD2D2DA;
        UiFont.draw(ctx, UiFont.trim(label, w - (hasSettings ? 24 : 10)), x + 5, y + 3, textColor);
        if (hasSettings) drawArrow(ctx, x + w - 10, y + 5, expanded.contains(m), 0xFF9A9AA6);
        addHit(x, y, x + w, y + ROW, Kind.MODULE, m, null, top, bottom);
        y += ROW;

        if (expanded.contains(m)) {
            int settingsHeight = 0;
            for (Object s : m.getSettings()) settingsHeight += settingHeight(s);
            Draw2D.roundedRect(ctx, x, y, x + w, y + settingsHeight, 3.0F, 0x38000000);
            for (Object s : m.getSettings()) y = drawSetting(ctx, s, x, y, w, top, bottom);
        }
        return y;
    }

    private int drawSetting(DrawContext ctx, Object s, int x, int y, int w, int top, int bottom) {
        int labelColor = 0xFFB4B4BE;
        if (s instanceof NumberSetting n) {
            String value = formatNumber(n);
            int valueWidth = UiFont.width(value);
            UiFont.draw(ctx, UiFont.trim(n.getName(), w - 16 - valueWidth), x + 6, y + 1, labelColor);
            UiFont.drawRight(ctx, value, x + w - 6, y + 1, 0xFFFFFFFF);
            int bx1 = x + 6, bx2 = x + w - 6, by = y + 14;
            double range = n.getMax() - n.getMin();
            double ratio = range <= 0 ? 0 : (n.getValue() - n.getMin()) / range;
            int fillTo = bx1 + (int) ((bx2 - bx1) * ratio);
            Draw2D.roundedRect(ctx, bx1, by, bx2, by + 2, 1.0F, 0x40FFFFFF);
            Draw2D.roundedRect(ctx, bx1, by, fillTo, by + 2, 1.0F, Theme.argb(0xFF));
            Draw2D.circle(ctx, fillTo, by + 1, 2.6F, 0xFFFFFFFF);
            addHit(x, y, x + w, y + SLIDER_ROW, Kind.NUMBER, null, n, top, bottom);
            return y + SLIDER_ROW;
        }
        if (s instanceof ModeSetting mode) {
            String value = mode.getValue();
            int valueWidth = UiFont.width(value);
            UiFont.draw(ctx, UiFont.trim(mode.getName(), w - 20 - valueWidth), x + 6, y + 2, labelColor);
            UiFont.drawRight(ctx, value, x + w - 6, y + 2, Theme.argb(0xFF));
            addHit(x, y, x + w, y + SETTING_ROW, Kind.MODE, null, mode, top, bottom);
            return y + SETTING_ROW;
        }
        if (s instanceof BindSetting bind) {
            String value = listeningBind == bind ? "..." : "[" + bind.getDisplayName() + "]";
            int valueWidth = UiFont.width(value);
            UiFont.draw(ctx, UiFont.trim(bind.getName(), w - 20 - valueWidth), x + 6, y + 2, labelColor);
            UiFont.drawRight(ctx, value, x + w - 6, y + 2, listeningBind == bind ? Theme.argb(0xFF) : 0xFFFFFFFF);
            addHit(x, y, x + w, y + SETTING_ROW, Kind.BIND, null, bind, top, bottom);
            return y + SETTING_ROW;
        }
        if (s instanceof BooleanSetting b) {
            UiFont.draw(ctx, UiFont.trim(b.getName(), w - 34), x + 6, y + 2, labelColor);
            int px = x + w - 22, py = y + 4;
            Draw2D.roundedRect(ctx, px, py, px + 16, py + 7, 3.5F, b.isEnabled() ? Theme.argb(0xFF) : 0x50FFFFFF);
            Draw2D.circle(ctx, b.isEnabled() ? px + 12.5F : px + 3.5F, py + 3.5F, 2.6F, 0xFFFFFFFF);
            addHit(x, y, x + w, y + SETTING_ROW, Kind.BOOL, null, b, top, bottom);
            return y + SETTING_ROW;
        }
        return y;
    }

    private void drawBottom(DrawContext ctx) {
        int sw = 160, sx = (width - sw) / 2, sy = height - 62;
        if (searchFocused) rrect(ctx, sx - 1, sy - 1, sx + sw + 1, sy + 17, Theme.argb(0xC0));
        rrect(ctx, sx, sy, sx + sw, sy + 16, 0xE0121218);
        if (search.isEmpty() && !searchFocused) {
            UiFont.drawCentered(ctx, "Search...", sx + sw / 2, sy + 3, 0xFF8C8C98);
        } else {
            String shown = search + (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "");
            UiFont.drawCentered(ctx, shown, sx + sw / 2, sy + 3, 0xFFFFFFFF);
        }
        hits.add(new Hit(sx, sy, sx + sw, sy + 16, Kind.SEARCH, null, null, 0));

        // theme color dots
        int spacing = 16;
        int dotsWidth = (DOTS.length - 1) * spacing;
        int x0 = (width - dotsWidth) / 2;
        int cy = height - 32;
        rrect(ctx, x0 - 14, cy - 9, x0 + dotsWidth + 14, cy + 9, 0xE0121218);
        for (int i = 0; i < DOTS.length; i++) {
            int cx = x0 + i * spacing;
            if ((DOTS[i] & 0xFFFFFF) == Theme.rgb()) circle(ctx, cx, cy, 7, 0xFFFFFFFF);
            circle(ctx, cx, cy, 5, 0xFF000000 | DOTS[i]);
            hits.add(new Hit(cx - 8, cy - 8, cx + 8, cy + 8, Kind.DOT, null, null, DOTS[i]));
        }
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        searchFocused = false;
        listeningBind = null;
        pressed = null;
        moved = false;
        dragPanel = null;
        for (PanelRect p : panels) if (p.contains(mx, my)) { dragPanel = p.cat(); break; }

        for (Hit h : hits) {
            if (!h.contains(mx, my)) continue;
            if (h.kind() == Kind.NUMBER) {
                if (button == 0) { slider = h; updateSlider(h, mx); }
                return true;
            }
            pressed = h;
            pressedButton = button;
            pressX = mx;
            pressY = my;
            return true;
        }
        pressX = mx;
        pressY = my;
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (slider != null) { updateSlider(slider, mx); return true; }
        if (!moved && Math.hypot(mx - pressX, my - pressY) > 4) moved = true;
        if (moved && dragPanel != null) {
            scrolls.merge(dragPanel, (int) -dy, Integer::sum);
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        slider = null;
        Hit h = pressed;
        pressed = null;
        dragPanel = null;
        if (h != null && !moved && h.contains(mx, my)) activate(h, pressedButton, pressX);
        moved = false;
        return true;
    }

    private void activate(Hit h, int button, double mx) {
        switch (h.kind()) {
            case MODULE -> {
                boolean hasSettings = !h.module().getSettings().isEmpty();
                boolean onArrow = mx >= h.x2() - 18;
                // right click, or a normal tap on the arrow (touch has no right click)
                if (hasSettings && (button == 1 || (button == 0 && onArrow))) {
                    if (!expanded.remove(h.module())) expanded.add(h.module());
                } else if (button == 0) {
                    h.module().toggle();
                }
            }
            case MODE -> ((ModeSetting) h.setting()).cycle();
            case BOOL -> ((BooleanSetting) h.setting()).toggle();
            case BIND -> listeningBind = (BindSetting) h.setting();
            case DOT -> { Theme.set(h.value()); ConfigManager.save(); }
            case SEARCH -> searchFocused = true;
            default -> { }
        }
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        for (PanelRect p : panels) {
            if (p.contains(mx, my)) {
                scrolls.merge(p.cat(), (int) (-vertical * 14), Integer::sum);
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listeningBind != null) { // waiting for a key to assign
            listeningBind.setKey(keyCode == GLFW.GLFW_KEY_ESCAPE ? 0 : keyCode);
            listeningBind = null;
            ConfigManager.save();
            return true;
        }
        if (searchFocused) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) search = search.substring(0, search.length() - 1);
            else if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) searchFocused = false;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE
                || (NovaClient.openGuiKey != null && NovaClient.openGuiKey.matchesKey(keyCode, scanCode))) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocused && chr >= 32 && search.length() < 24) {
            search += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    // ------------------------------------------------------------------ helpers

    private void updateSlider(Hit h, double mx) {
        NumberSetting n = (NumberSetting) h.setting();
        double ratio = Math.max(0.0, Math.min(1.0, (mx - (h.x1() + 6)) / (double) (h.x2() - h.x1() - 12)));
        n.setValue(n.getMin() + ratio * (n.getMax() - n.getMin()));
    }

    /** Adds a click area, cut to the visible part of the panel so hidden rows can not be clicked. */
    private void addHit(int x1, int y1, int x2, int y2, Kind kind, Module module, Object setting, int top, int bottom) {
        int cy1 = Math.max(y1, top);
        int cy2 = Math.min(y2, bottom);
        if (cy1 < cy2) hits.add(new Hit(x1, cy1, x2, cy2, kind, module, setting, 0));
    }

    private List<Module> visibleModules(Category cat) {
        List<Module> out = new ArrayList<>();
        String q = search.toLowerCase(Locale.ROOT);
        for (Module m : ModuleManager.getModules()) {
            if (m.getCategory() != cat) continue;
            if (!q.isEmpty() && !m.getName().toLowerCase(Locale.ROOT).contains(q)) continue;
            out.add(m);
        }
        return out;
    }

    private int moduleHeight(Module m) {
        int h = ROW;
        if (expanded.contains(m)) {
            for (Object s : m.getSettings()) h += settingHeight(s);
        }
        return h;
    }

    private static int settingHeight(Object s) {
        return s instanceof NumberSetting ? SLIDER_ROW : SETTING_ROW;
    }

    private static String formatNumber(NumberSetting n) {
        return n.getStep() >= 1.0
                ? String.format(Locale.ROOT, "%.0f", n.getValue())
                : String.format(Locale.ROOT, n.getStep() >= 0.1 ? "%.1f" : "%.2f", n.getValue());
    }

    /** Small arrow: points right when closed, down when open. */
    private static void drawArrow(DrawContext ctx, int x, int y, boolean open, int color) {
        if (open) {
            ctx.fill(x, y + 1, x + 7, y + 2, color);
            ctx.fill(x + 1, y + 2, x + 6, y + 3, color);
            ctx.fill(x + 2, y + 3, x + 5, y + 4, color);
            ctx.fill(x + 3, y + 4, x + 4, y + 5, color);
        } else {
            ctx.fill(x + 1, y, x + 2, y + 7, color);
            ctx.fill(x + 2, y + 1, x + 3, y + 6, color);
            ctx.fill(x + 3, y + 2, x + 4, y + 5, color);
            ctx.fill(x + 4, y + 3, x + 5, y + 4, color);
        }
    }

    /** Rectangle with slightly rounded corners. */
    private static void rrect(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        Draw2D.roundedRect(ctx, x1, y1, x2, y2, 3.5F, color);
    }

    private static void circle(DrawContext ctx, int cx, int cy, int r, int color) {
        Draw2D.circle(ctx, cx, cy, r, color);
    }
}
