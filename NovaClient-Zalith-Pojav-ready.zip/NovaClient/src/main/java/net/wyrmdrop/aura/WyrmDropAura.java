package net.wyrmdrop.aura;

import net.minecraft.client.MinecraftClient;
import com.nova.client.rotation.RotationManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.BlockHitResult;

import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * WyrmDrop — Silent/Focused Aura mimari iskeleti
 * Hedef: Minecraft 1.21.4 / Fabric
 *
 * BU KOD ÇALIŞMAZ. Her blok, doğru yere konduğunda çalışacak
 * mantığı ve matematiği gösterir. Mixin noktaları yorumlarda.
 *
 * Paket akışı özeti:
 *   Client tick → Camera (gerçek bakış) → SilentRotationManager
 *   → PlayerMoveC2SPacket (yaw/pitch değiştirilmiş) → Server
 *   Server, paketteki yaw/pitch'e göre vuruş yönünü işler.
 *   İstemci ekranı ise Camera'nın gerçek yaw/pitch'ini çizer.
 */
public final class WyrmDropAura {

    // =====================================================================
    // 1. SILENT ROTATION & FOCUS — mantıksal ayrışma
    // =====================================================================
    /*
     * Temel fikir: İki ayrı yaw/pitch durumu tut.
     *
     *   cameraYaw / cameraPitch   → oyuncunun ekranda gördüğü, fareyle kontrol ettiği
     *   silentYaw / silentPitch   → sunucuya gönderilecek, hedefe kilitlenmiş
     *
     * Mixin noktası:
     *   PlayerMoveC2SPacket.LookAndOnGround  (veya PlayerMoveC2SPacket.Full)
     *   constructor'ında yaw/pitch alanlarını silent değerlerle değiştir.
     *
     *   ClientPlayerEntity.sendMovementPackets() içinde:
     *     float yaw = this.getYaw();       // camera
     *     float pitch = this.getPitch();   // camera
     *   yerine:
     *     float yaw = SilentRotationManager.getSilentYaw(cameraYaw);
     *     float pitch = SilentRotationManager.getSilentPitch(cameraPitch);
     *
     * Movement fix:
     *   Sunucu seni silent yaw'a göre hareket ettirir. Ama sen kameranın
     *   yönünde yürümek istiyorsun. Bu yüzden W/A/S/D input vektörünü
     *   cameraYaw ile değil, (silentYaw - cameraYaw) farkıyla döndür.
     *
     *   Vec3d input = new Vec3d(strafe, 0, forward);
     *   input = input.rotateY(-(silentYaw - cameraYaw) * MathHelper.RADIANS_PER_DEGREE);
     *   // sonra normal movement uygula
     *
     *   Aksi halde sunucu seni yanlış yöne çeker (özellikle strafe'de).
     */

    private static float silentYaw = 0f;
    private static float silentPitch = 0f;
    private static boolean silentActive = false;
    private static boolean rotationInitialized = false;
    private static LivingEntity currentTarget = null;

    /** Current target for NovaClient visual modules. */
    public static LivingEntity getTarget() { return currentTarget; }
    public static void clearTarget() {
        currentTarget = null;
        silentActive = false;
        rotationInitialized = false;
        RotationManager.clear();
        RotationManager.clearMove();
    }

    public static float getSilentYaw(float cameraYaw) {
        return silentActive ? silentYaw : cameraYaw;
    }

    public static float getSilentPitch(float cameraPitch) {
        return silentActive ? silentPitch : cameraPitch;
    }

    // =====================================================================
    // 2. SMOOTHING & JITTER — Lerp/Slerp + insanileştirme
    // =====================================================================
    /*
     * Hedefe kilitlenirken ani snap yok. Her tick'te açıyı hedefe doğru
     * kademeli çek. İki seçenek:
     *
     *   Lerp (lineer):  angle = start + (target - start) * t
     *     Basit, ama büyük açı farklarında hız sabit değil.
     *
     *   Slerp (küresel): büyük açılarda daha doğal, sabit açısal hız.
     *     Ama Minecraft yaw/pitch zaten Euler açısı; Slerp için quaternion'a
     *     çevirmek gerekir. Pratikte çoğu client Lerp kullanır.
     *
     * Formül (Lerp, tick başına):
     *   t = 1 - exp(-speed * deltaTime)   // frame-rate bağımsız
     *   veya sabit tick: t = speed (0..1 arası, genelde 0.3–0.6)
     *
     *   silentYaw   += (targetYaw   - silentYaw)   * t;
     *   silentPitch += (targetPitch - silentPitch) * t;
     *
     * Jitter / Humanization:
     *   Anti-cheat, açı değişimlerindeki düzenliliği arar. Her tick'te
     *   hedef açıya küçük rastgele sapma ekle:
     *
     *   float jitterYaw   = (random.nextFloat() - 0.5f) * jitterAmount;   // ±0.15°
     *   float jitterPitch = (random.nextFloat() - 0.5f) * jitterAmount;
     *
     *   Ama dikkat: jitter her tick değişirse "titreme" gibi görünür.
     *   Daha iyisi: hedef açıyı belirlerken bir kez jitter ekle, smoothing
     *   sırasında sabit tut. Veya jitter'ı düşük frekanslı bir sinüs ile modüle et.
     *
     *   Örnek:
     *     long tick = System.currentTimeMillis() / 50;
     *     float jitter = (float) Math.sin(tick * 0.3) * 0.08f;
     */

    private static final Random random = new Random();
    private static float jitterAmount = 0.12f;

    private static float smoothAngle(float current, float target, float speed) {
        // Açı farkını -180..180 aralığına indir (yaw için kritik)
        float delta = MathHelper.wrapDegrees(target - current);
        return current + delta * speed;
    }

    private static float applyJitter(float angle, float amount) {
        return angle + (random.nextFloat() - 0.5f) * amount;
    }

    // =====================================================================
    // 3. TARGET SELECTION — EntityManager & filtreleme
    // =====================================================================
    /*
     * Her tick'te çalışır. Sıra:
     *
     *   1) Dünya'daki tüm LivingEntity'leri al (oyuncu kendisi hariç)
     *   2) Reach filtresi: squaredDistance <= reach²
     *   3) FOV filtresi: hedefin yönü ile bakış yönü arasındaki açı <= fov/2
     *   4) Raytrace filtresi: gözden hedefe giden ışın blokla kesiliyor mu?
     *   5) En yakın / en düşük açılı olanı seç
     *
     * FOV hesabı (düzlem üzerinde):
     *   Vec3d look = Vec3d.fromPolar(cameraPitch, cameraYaw);  // birim vektör
     *   Vec3d toTarget = target.getPos().add(0, target.getHeight()/2, 0)
     *                       .subtract(mc.player.getEyePos()).normalize();
     *   double angle = Math.toDegrees(Math.acos(look.dotProduct(toTarget)));
     *   // angle <= fov/2 ise geçerli
     *
     * Raytrace (1.21.4):
     *   Vec3d eyes = mc.player.getEyePos();
     *   Vec3d targetCenter = target.getBoundingBox().getCenter();
     *   BlockHitResult hit = mc.world.raycast(new RaycastContext(
     *       eyes, targetCenter,
     *       RaycastContext.ShapeType.COLLIDER,
     *       RaycastContext.FluidHandling.NONE,
     *       mc.player
     *   ));
     *   if (hit.getType() != HitResult.Type.MISS) → duvar var, hedef geçersiz
     *
     * Not: Raytrace her tick her entity için pahalıdır. Önce reach+FOV
     * filtresi uygula, sonra sadece en umut verici 1-3 adaya raytrace at.
     */

    private static LivingEntity selectTarget(MinecraftClient mc, float reach, float fov) {
        Vec3d eyes = mc.player.getEyePos();
        Vec3d look = Vec3d.fromPolar(mc.player.getPitch(), mc.player.getYaw()).normalize();

        List<LivingEntity> candidates = mc.world.getEntitiesByClass(
                LivingEntity.class,
                mc.player.getBoundingBox().expand(reach),
                e -> e != mc.player && e.isAlive()
        );

        return candidates.stream()
                .filter(e -> mc.player.squaredDistanceTo(e) <= reach * reach)
                .filter(e -> {
                    Vec3d toTarget = e.getBoundingBox().getCenter().subtract(eyes).normalize();
                    double angle = Math.toDegrees(Math.acos(
                            MathHelper.clamp(look.dotProduct(toTarget), -1.0, 1.0)
                    ));
                    return angle <= fov / 2.0;
                })
                .filter(e -> {
                    // Raytrace — sadece FOV içindekilere
                    Vec3d center = e.getBoundingBox().getCenter();
                    BlockHitResult hit = mc.world.raycast(new RaycastContext(
                            eyes, center,
                            RaycastContext.ShapeType.COLLIDER,
                            RaycastContext.FluidHandling.NONE,
                            mc.player
                    ));
                    return hit.getType() == HitResult.Type.MISS;
                })
                .min(Comparator.comparingDouble(e -> mc.player.squaredDistanceTo(e)))
                .orElse(null);
    }

    // =====================================================================
    // 4. ATTACK TIMING & COOLDOWN — tick tabanlı senkronizasyon
    // =====================================================================
    /*
     * 1.9+ combat sistemi: her vuruş arasında cooldown var.
     * Cooldown dolmadan vurursan hasar düşer.
     *
     * Formül (Minecraft Wiki):
     *   attackSpeed = item'ın attack_speed attribute'u (varsayılan 4)
     *   T = 20 / attackSpeed   (tick cinsinden tam cooldown süresi)
     *   t = son vuruştan bu yana geçen tick
     *   p = clamp((t + 0.5) / T, 0, 1)   // cooldown completion
     *
     *   Hasar çarpanı = 0.2 + 0.8 * p²
     *
     * Yani p=1 olduğunda tam hasar (çarpan 1.0).
     * p=0.5 iken çarpan = 0.2 + 0.8*0.25 = 0.4 (sadece %40 hasar).
     *
     * Silent aura için strateji:
     *   - p >= 0.95 olana kadar bekle (tam vuruşa yakın)
     *   - veya CPS hedefine göre: örneğin 8 CPS istiyorsan her 2.5 tick'te bir
     *     vur, ama p düşükse hasar azalır.
     *
     *   En verimli: p >= 0.99 olduğunda vur. Attack speed 4 ise T=5 tick,
     *   yani her 5 tick'te bir tam hasar vuruşu = 4 CPS.
     *   Daha yüksek CPS istiyorsan hasar düşüşünü kabul et.
     *
     * Kod:
     *   int ticksSinceLastAttack = ...
     *   float attackSpeed = mc.player.getAttributeValue(EntityAttributes.ATTACK_SPEED);
     *   float T = 20f / attackSpeed;
     *   float p = MathHelper.clamp((ticksSinceLastAttack + 0.5f) / T, 0f, 1f);
     *
     *   if (p >= 0.95f && target != null && target.isAlive()) {
     *       mc.interactionManager.attackEntity(mc.player, target);
     *       mc.player.swingHand(Hand.MAIN_HAND);
     *       ticksSinceLastAttack = 0;
     *   }
     *
     * Dikkat: mc.interactionManager.attackEntity çağrısı kendi başına
     * PlayerInteractEntityC2SPacket gönderir. Silent rotation aktifken
     * bu paket silent yaw/pitch ile gitmeli. Yani silent rotation
     * güncellemesi attack'ten ÖNCE yapılmalı (aynı tick içinde).
     */

    private static int ticksSinceLastAttack = 0;

    private static boolean shouldAttack(MinecraftClient mc, LivingEntity target) {
        if (target == null || !target.isAlive()) return false;

        float attackSpeed = (float) mc.player.getAttributeValue(
                net.minecraft.entity.attribute.EntityAttributes.ATTACK_SPEED
        );
        float T = 20f / attackSpeed;
        float p = MathHelper.clamp((ticksSinceLastAttack + 0.5f) / T, 0f, 1f);

        return p >= 0.95f;
    }

    // =====================================================================
    // ANA TICK — her client tick'inde çağrılır
    // =====================================================================
    /*
     * Mixin noktası: ClientPlayerEntity.tick()  (TAIL veya HEAD)
     * veya Fabric API ClientTickEvents.END_CLIENT_TICK
     *
     * Sıra kritik:
     *   1) Hedef seç
     *   2) Hedef varsa hedef açıyı hesapla (yaw/pitch)
     *   3) Silent rotation'ı smooth et (jitter ekle)
     *   4) Cooldown kontrolü → vur
     *   5) Movement fix uygula (paket gönderilmeden önce)
     */
    public static void onClientTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            clearTarget();
            return;
        }

        ticksSinceLastAttack++;

        // 1) Hedef seç
        LivingEntity target = selectTarget(mc, 3.0f, 120f); // reach 3, FOV 120°

        currentTarget = target;
        if (target == null) {
            clearTarget();
            return;
        }

        if (!rotationInitialized) {
            silentYaw = mc.player.getYaw();
            silentPitch = mc.player.getPitch();
            rotationInitialized = true;
        }
        silentActive = true;

        // 2) Hedef açı hesapla
        Vec3d eyes = mc.player.getEyePos();
        Vec3d targetCenter = target.getBoundingBox().getCenter();
        Vec3d diff = targetCenter.subtract(eyes);

        float targetYaw = (float) Math.toDegrees(Math.atan2(-diff.x, diff.z));
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y,
                Math.sqrt(diff.x * diff.x + diff.z * diff.z)));

        // 3) Smooth + jitter
        float speed = 0.45f; // tick başına yaklaşma oranı
        silentYaw = smoothAngle(silentYaw, applyJitter(targetYaw, jitterAmount), speed);
        silentPitch = MathHelper.clamp(
                smoothAngle(silentPitch, applyJitter(targetPitch, jitterAmount), speed), -90.0f, 90.0f);

        // Connect the calculated rotation to NovaClient's existing packet rotation mixin.
        RotationManager.set(silentYaw, silentPitch);

        // Attack is intentionally deferred until sendMovementPackets returns.
        // That way the server receives the rotation update before the attack packet.
    }

    /** Called immediately after movement packets have been sent for this tick. */
    public static void onPostMovementPackets(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        LivingEntity target = currentTarget;
        if (!silentActive || target == null || !target.isAlive()) return;
        if (shouldAttack(mc, target)) {
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            ticksSinceLastAttack = 0;
        }
    }

    // =====================================================================
    // MIXIN İSKELETLERİ (yorum — gerçek mixin dosyaları ayrı olmalı)
    // =====================================================================
    /*
     * @Mixin(PlayerMoveC2SPacket.class)
     * public class PlayerMoveC2SPacketMixin {
     *     @Inject(method = "<init>", at = @At("RETURN"))
     *     private void onConstruct(CallbackInfo ci) {
     *         // this.yaw ve this.pitch alanlarını silent değerlerle override et
     *         // PlayerMoveC2SPacket.LookAndOnGround için:
     *         //   this.yaw = WyrmDropAura.getSilentYaw(this.yaw);
     *         //   this.pitch = WyrmDropAura.getSilentPitch(this.pitch);
     *     }
     * }
     *
     * @Mixin(ClientPlayerEntity.class)
     * public class ClientPlayerEntityMixin {
     *     @Inject(method = "sendMovementPackets", at = @At("HEAD"))
     *     private void beforeSend(CallbackInfo ci) {
     *         WyrmDropAura.onClientTick(MinecraftClient.getInstance());
     *     }
     * }
     *
     * Movement fix için: ClientPlayerEntity.tickMovement() içinde
     * input vektörünü silentYaw - cameraYaw farkıyla döndür.
     */
}
